package Hex;

public class App {
    public static void main(String[] args) {
        System.out.print("Start -> \n");
        Window window = new Window();
        window.run();
        System.out.print("End <- \n");
    }
}
