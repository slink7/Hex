package Hex;

import java.awt.Color;

public class Player {
    int ID;
    Color color;

    Player(int ID, Color color){
        this.ID = ID;
        this.color = color;
    }
}